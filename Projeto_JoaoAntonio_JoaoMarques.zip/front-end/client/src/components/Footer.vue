<template>
  <v-footer height="auto" color="grey darken-4" class="mt-5">
    <v-layout justify-center row wrap>
      <v-btn flat dark to="/">Home</v-btn>
      <v-btn flat dark to="/create">Create</v-btn>
      <v-btn flat dark to="/login">Login</v-btn>
      <v-btn flat dark to="/signup">Signup</v-btn>
      <v-flex grey darken-2 py-3 text-xs-center white--text xs12>
        &copy;2019 —
        <strong>João Abreu e João Marques</strong>
      </v-flex>
    </v-layout>
  </v-footer>
</template>
